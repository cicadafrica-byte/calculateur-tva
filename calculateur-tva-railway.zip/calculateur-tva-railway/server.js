const express=require("express");
const sqlite3=require("sqlite3").verbose();
const fs=require("fs");
const path=require("path");
const app=express();
const port=process.env.PORT||3000;
const dataDir=process.env.DATA_DIR||process.env.RAILWAY_VOLUME_MOUNT_PATH||"/data";
fs.mkdirSync(dataDir,{recursive:true});
const dbPath=path.join(dataDir,"calculs.sqlite");
const db=new sqlite3.Database(dbPath);
app.use(express.json({limit:"20kb"}));
app.use(express.static(path.join(__dirname,"public")));
db.serialize(()=>db.run(`CREATE TABLE IF NOT EXISTS calculations(
 id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 input_type TEXT NOT NULL, amount REAL NOT NULL, rate REAL NOT NULL,
 ht REAL NOT NULL, tva REAL NOT NULL, ttc REAL NOT NULL)`));
const round=n=>Math.round((n+Number.EPSILON)*100)/100;
app.get("/api/health",(_req,res)=>db.get("SELECT 1 AS ok",[],err=>err?res.status(500).json({ok:false}):res.json({ok:true,database:"sqlite",path:dbPath})));
app.get("/api/calculations",(_req,res)=>db.all("SELECT * FROM calculations ORDER BY id DESC LIMIT 100",[],(err,rows)=>err?res.status(500).json({error:"Lecture impossible"}):res.json(rows)));
app.post("/api/calculations",(req,res)=>{
 const {inputType,amount,rate}=req.body||{}, value=Number(amount), vatRate=Number(rate);
 if(!["HT","TTC","TVA"].includes(inputType)||!Number.isFinite(value)||value<0||value>1e15||!Number.isFinite(vatRate)||vatRate<0||vatRate>100)return res.status(400).json({error:"Montant, type ou taux invalide."});
 const f=vatRate/100; let ht,tva,ttc;
 if(inputType==="HT"){ht=value;tva=value*f;ttc=ht+tva}
 else if(inputType==="TTC"){ttc=value;ht=value/(1+f);tva=ttc-ht}
 else {if(f===0)return res.status(400).json({error:"Le taux doit être supérieur à 0 pour calculer depuis la TVA."});tva=value;ht=value/f;ttc=ht+tva}
 ht=round(ht);tva=round(tva);ttc=round(ttc);
 db.run("INSERT INTO calculations(input_type,amount,rate,ht,tva,ttc) VALUES(?,?,?,?,?,?)",[inputType,value,vatRate,ht,tva,ttc],function(err){
  if(err)return res.status(500).json({error:"Enregistrement impossible."});
  res.status(201).json({id:this.lastID,inputType,amount:value,rate:vatRate,ht,tva,ttc});
 });
});
app.delete("/api/calculations",(_req,res)=>db.run("DELETE FROM calculations",[],err=>err?res.status(500).json({error:"Effacement impossible"}):res.json({ok:true})));
app.delete("/api/calculations/:id",(req,res)=>{
 const id=Number(req.params.id);if(!Number.isInteger(id)||id<1)return res.status(400).json({error:"Identifiant invalide"});
 db.run("DELETE FROM calculations WHERE id=?",[id],function(err){if(err)return res.status(500).json({error:"Suppression impossible"});if(!this.changes)return res.status(404).json({error:"Calcul introuvable"});res.json({ok:true})});
});
app.listen(port,"0.0.0.0",()=>console.log(`Calculateur sur port ${port}; SQLite: ${dbPath}`));