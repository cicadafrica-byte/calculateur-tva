# Calculateur HT / TVA / TTC

## Local
Prérequis : Node.js 20+. Dans un terminal, à la racine du dossier :
```bash
npm install
npm start
```
Ouvrir http://localhost:3000

## Railway
1. Envoyer ce dossier dans un dépôt GitHub.
2. Dans Railway, créer un projet depuis ce dépôt.
3. Dans le service, ajouter un Volume avec le chemin de montage `/data`.
4. Le serveur utilise `/data/calculs.sqlite` (ou le chemin fourni par Railway).
5. Dans Settings > Networking, cliquer sur Generate Domain.
6. Après déploiement, tester `https://VOTRE-DOMAINE/api/health`, effectuer un calcul, redéployer puis vérifier que l'historique persiste.

Commande de démarrage : `npm start`.

## Sécurité
Cette version de démonstration expose l'historique commun et les routes de suppression sans authentification. Toute personne connaissant le lien peut consulter ou effacer les calculs. Avant usage professionnel, ajouter comptes, autorisations, limitation de débit et sauvegardes. Le volume n'est pas une sauvegarde.
